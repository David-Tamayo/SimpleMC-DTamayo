
import math as N
from LCDMCosmology import *

import scipy as sci
from scipy import special

####### define parameters of the model #######
class wzDE(LCDMCosmology):
    def __init__(self, varya1=True, varyb1=True, varya2=False, varyb2=False, varyOk=False):

        self.varya1 = varya1
        self.varyb1 = varyb1
        self.varya2 = varya2
        self.varyb2 = varyb2
        self.varyOk = varyOk

        self.Ok = Ok_par.value   
        self.a1 = a1_par.value
        self.b1 = b1_par.value
        self.a2 = a2_par.value
        self.b2 = b2_par.value
        LCDMCosmology.__init__(self)

    def freeParameters(self):
        l=LCDMCosmology.freeParameters(self)
        if (self.varya1): l.append(a1_par)
        if (self.varyb1): l.append(b1_par)
        if (self.varya2): l.append(a2_par)
        if (self.varyb2): l.append(b2_par)
        if (self.varyOk): l.append(Ok_par)
        return l

    def updateParams(self,pars):
        ok=LCDMCosmology.updateParams(self,pars)
        if not ok:
            return False
        for p in pars:
            if p.name=="a_1":
                self.a1=p.value
            elif p.name=="b_1":
                self.b1=p.value
            elif p.name=="a_2":
                self.a2=p.value
            elif p.name=="b_2":
                self.b2=p.value
            elif p.name=="Ok":
                self.Ok=p.value
                self.setCurvature(self.Ok)
                if (abs(self.Ok)>1.0):
                   return False
        return True
#########################################

    def RHSquared_a(self,a):
        #NuContrib=self.NuDensity.rho(a)/self.h**2

        zini = 3.0
        zmed = 2.8
        zfin = 0.0
        aini = 1.0/(1.0 + zini)
        amed = 1.0/(1.0 + zmed)
        afin = 1.0/(1.0 + zfin)
        T = afin - amed
        theta = 2.0*N.pi/T
        wmed = -1.0 +self.b1 + self.b2
        
        Si_a_theta, Ci_a_theta = sci.special.sici(a*theta)
        Si_a_2theta, Ci_a_2theta = sci.special.sici(a*2*theta)
        Si_theta, Ci_theta = sci.special.sici(theta)
        Si_2theta, Ci_2theta = sci.special.sici(2*theta)
        Si_amed_theta, Ci_amed_theta = sci.special.sici(amed*theta)
        Si_amed_2theta, Ci_amed_2theta = sci.special.sici(amed*2*theta)

        f1 = self.b1*N.cos(amed*theta) - self.a1*N.sin(amed*theta)
        f2 = self.a1*N.cos(amed*theta) + self.b1*N.sin(amed*theta) 
        f3 = self.b2*N.cos(2.0*amed*theta) - self.a2*N.sin(2.0*amed*theta) 
        f4 = self.a2*N.cos(2.0*amed*theta) + self.b2*N.sin(2.0*amed*theta) 
        gamma = (self.b1 + self.b2)/(amed - aini)

        g  = Ci_a_theta*f1 + Si_a_theta*f2 + Ci_a_2theta*f3 + Si_a_2theta*f4
        g1 = Ci_theta*f1 + Si_theta*f2 + Ci_2theta*f3 + Si_2theta*f4
        g2 = amed*gamma + f1*(Ci_theta-Ci_amed_theta) + f2*(Si_theta-Si_amed_theta) + f3*(Ci_2theta-Ci_amed_2theta) + f4*(Si_2theta-Si_amed_2theta)
        g3 = aini*gamma - amed*gamma - f1*(Ci_theta-Ci_amed_theta) - f2*(Si_theta-Si_amed_theta) - f3*(Ci_2theta-Ci_amed_2theta) - f4*(Si_2theta-Si_amed_2theta)
    
        rho_C = aini**(3.0*aini*gamma)*amed**(-3.0*aini*gamma)*N.exp(-3.0*g3)
        rho_L = a**(3.0*aini*gamma)*amed**(-3.0*aini*gamma)*N.exp(-3.0*(a*gamma-g2)) 
        rho_F = N.exp(-3.0*(g-g1))
                   
        if a > amed:
            return self.Om/a**3 +(1.0-self.Om)*rho_F 
        elif amed > a > aini:
            return self.Om/a**3 +(1.0-self.Om)*rho_L
        else:
            return self.Om/a**3 +(1.0-self.Om)*rho_C
        
#    def RHSquared_a(self,a):
#        NuContrib=self.NuDensity.rho(a)/self.h**2
#        
#        zini = 0.0
#        zmed = 2.8
#        zfin = 3.0
#        aini = 1.0/(1.0 + zini)
#        amed = 1.0/(1.0 + zmed)
#        afin = 1.0/(1.0 + zfin)
#        T = afin - amed
#        theta = 2.0*N.pi/T
#        wmed = -1 +self.b1 + self.b2
#        
#        Si_a_theta, Ci_a_theta = sci.special.sici(a*theta)
#        Si_a_2theta, Ci_a_2theta = sci.special.sici(a*2*theta)
#        Si_amed_theta, Ci_amed_theta = sci.special.sici(amed*theta)
#        Si_amed_2theta, Ci_amed_2theta = sci.special.sici(amed*2*theta)
#        
#        si2 = Si_a_theta - Si_amed_theta
#        si4 = Si_a_2theta - Si_amed_2theta
#        ci2 = Ci_a_theta - Ci_amed_theta 
#        ci4 = Ci_a_2theta - Ci_amed_2theta 
#        f1 = N.cos(amed*theta)*self.b1 - N.sin(amed*theta)*self.a1
#        f2 = N.cos(amed*theta)*self.a1 + N.sin(amed*theta)*self.b1
#        f3 = N.cos(amed*2*theta)*self.b2 - N.sin(amed*2*theta)*self.a2
#        f4 = N.cos(amed*2*theta)*self.a2 + N.sin(amed*2*theta)*self.b2
#        g = ((self.b1+self.b2)*(-aini +amed +aini*N.log(aini) -aini*N.log(amed)))/(aini-amed)
#        
#        rhoFourier = N.exp(-3*(ci2*f1 +si2*f2 +ci4*f3 +si4*f4 -g))
#        rhoLineal  = N.exp((3*(self.b1 +self.b2)*(a -aini -aini*N.log(a) +aini*N.log(aini)))/(aini -amed))
#        
#        if a > amed:
#            return self.Ocb/a**3+self.Ok/a**2+self.Omrad/a**4+NuContrib+(1.0-self.Om-self.Ok)*rhoFourier 
#        elif amed > a > aini:
#            return self.Ocb/a**3+self.Ok/a**2+self.Omrad/a**4+NuContrib+(1.0-self.Om-self.Ok)*rhoLineal 
#        else:
#            return self.Ocb/a**3+self.Ok/a**2+self.Omrad/a**4+NuContrib+(1.0-self.Om-self.Ok)*1.0 
