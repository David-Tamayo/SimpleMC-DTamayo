getdist.covmat
==================================



.. automodule:: getdist.covmat
   :members:




   