getdist.parampriors
==================================



.. automodule:: getdist.parampriors
   :members:




   