PySide modules
**************

Qt is splitted in several modules.

.. toctree::
    :maxdepth: 1

    PySide/QtCore/index.rst
    PySide/QtDeclarative/index.rst
    PySide/QtGui/index.rst
    PySide/QtHelp/index.rst
    PySide/QtMaemo5/index.rst
    PySide/QtMultimedia/index.rst
    PySide/QtNetwork/index.rst
    PySide/QtOpenGL/index.rst
    PySide/QtScript/index.rst
    PySide/QtScriptTools/index.rst
    PySide/QtSql/index.rst
    PySide/QtSvg/index.rst
    PySide/QtUiTools/index.rst
    PySide/QtXml/index.rst
    PySide/QtWebKit/index.rst
    PySide/phonon/index.rst
